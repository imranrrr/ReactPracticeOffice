export const started_game="get_game_started";
export const set_Instruction="Set_Instruction";
 export const Fetch_Deck_Result="Fetch_Deck_Result";