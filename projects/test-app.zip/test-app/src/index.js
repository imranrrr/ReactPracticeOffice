import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Arrow from './playground/arrow-finction';
import * as serviceWorker from './serviceWorker';
import Bio from './New/Bio';
import Counter from './New/count';
import Practice from './component/PracticeState';
;


// const square=function(x)
// {
//     return x*x;
// };


// const option=(op)=>
// {
//     if(op.length>=4)
//     {
//         return "true";
//     }
//     else{
//         return 'false';
//     }
// }   

// const getFirstName=(name)=>
// {
// // console.log(arguments);
// return name.split(' ')[0];
// }   

// var user="Indecision App";

// var user={
//     name: "imran latif",
//     address:"rrr",
//     lan:"ENg",
//     option:["one","two"]

// };
// var t=
//     <div>
//         <h1>Name: {user.name ? getFirstName(user.name,user.address): "UNkonown"}</h1>
//         <p>option:{option(user.option)}</p>
//         <hr/>
//         <span>Language{user.lan}
//         </span>
//     </div>;




// var user={

// name:"imran",
// Gender:"M",
// cities:['lhr','fsd','skp'],
// info:function()
// {
//         console.log(this.name);
//         console.log(this.Gender);
//         console.log(this.cities)
//         this.cities.map((city)=> 
//     {

//         // console.log(city+' '+this.Gender);
//           console.log(city);


//     });
//     // console.log(m);
    
// }}

// const im={
// name:"kamran",
// lan:"eng",
// cities:["lhr","mul","kar"],


// print(){

// return this.cities.map((city) =>  "I am "+this.name+" belogs to "+city+" "+this.lan);

// }


// };

// const mul={
// a:3,
// b:[4,5,6],
// multiply()
// {

//     return this.b.map((b1) => b1*this.a);

// }

// };




// const count=0

// const element=(
// <div>
//     <h1>Count:{count} </h1>
// </div>


// );













ReactDOM.render(<Counter/>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
