import pro1 from '../assets/project1.png';
import pro2 from '../assets/project2.png';
import pro3 from '../assets/project3.png';


const TITLE=['BSSE','BSCS','ELEC','PHY','CHE'];

const PROJECTS=[
    {

        title:"Porject1",
        description:"A react Project that I built ",
        link:"https://github.com/15Dkatz",
        image:pro1

    },
    {
        title:"Porject2",
        description:"A react Project that I built ",
        link:"https://github.com/15Dkatz",
        image:pro2

    },
    {
        title:"Porject3",
        description:"A react Project that I built ",
        link:"https://github.com/15Dkatz",
        image:pro3

    }
];
export default PROJECTS;