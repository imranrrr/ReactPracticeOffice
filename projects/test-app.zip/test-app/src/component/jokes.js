import React,{Component} from 'react';

class joke extends Component{


    state={ joke:{} };
    componentDidMount(){

        fetch('https://official-joke-api.appspot.com/random_joke')
        .then(Response=>Response.json())
        .then(json => this.setState({joke:json}));
    }
    render(){
        const{punchline,setup}=this.state.joke;
        console.log(punchline);
    return(
            <div>

            <h1>{punchline}</h1>
            <hr/>
            <h2>{setup}</h2>
            </div>


    );
    
    }


}
export default joke;